# Cricbot-python-
This project has done using socket programming.



First run the servercode and
run the client code, it will ask host and port number, host will be the ipv4 of system where you are running the server code
eg: host:127.0.0.1 (if you are running both codes in same system)
    port: 33000
Tkinter interface will open for bot    
    
    
